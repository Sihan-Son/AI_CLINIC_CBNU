import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

#Number of data : Full 6317 FW 997 MF 2785 DF 2533
xy_data = np.loadtxt("C:/Temp/Full_Data.csv", delimiter=",", dtype=np.float32)
# 데이터 정규화
# row_sums = xy_data.sum(axis=1)
# xy_data = xy_data / row_sums[:, np.newaxis]
#전체 데이터
x_data = xy_data[:, 0: -1]
y_data = xy_data[:, [-1]]

#테스트 데이터
# 포지션 별 100명 추출
x_FWTest = x_data[201:300]
y_FWTest = y_data[201:300]
x_MFTest = x_data[4001:4100]
y_MFTest = y_data[4001:4100]
x_DFTest = x_data[6201:6300]
y_DFTest = y_data[6201:6300]
x_dataTest = np.concatenate((x_FWTest, x_MFTest, x_DFTest))
y_dataTest = np.concatenate((y_FWTest, y_MFTest, y_DFTest))

X = tf.placeholder(tf.float32, shape=[None, 30])
Y = tf.placeholder(tf.float32, shape=[None, 1])

W = tf.Variable((tf.random_normal([30, 1])), name="weight")
b = tf.Variable(tf.random_normal([1]), name='bias')

H = tf.matmul(X, W) + b

cost = tf.reduce_mean(tf.square(H - Y))
# Set the optimizer and learning_rate
optimizer = tf.train.GradientDescentOptimizer(learning_rate=8e-6)
#optimizer = tf.train.AdamOptimizer(learning_rate=3)
train = optimizer.minimize(cost)

cost_list = []
acc_list = []
error_list = []
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    for step in range(10001):
        _c, _h, _ = sess.run([cost, H, train], feed_dict={X: x_data, Y: y_data})
        cost_list.append(_c)
    i=0
    for data in x_dataTest:
        result = abs(sess.run(H, feed_dict={X:[data]}))
        real = y_dataTest[i]
        errorRate = abs(result - real) / result * 100
        if(result>=real):
            acc = real / result
        else:
            acc = result / real
        print("Predicted stat : ", result, ", Real stat : ", real, ", Accurancy : ", acc)

        error_list.append(errorRate[0])
        acc_list.append(acc[0])
        i += 1

accAvg = np.mean(acc_list)
errorAvg = np.mean(error_list)
print("Cost : ", _c, ", Accurancy : ", accAvg, ", Error rate : ", errorAvg)


fig, ax = plt.subplots(1, 2)
fig.suptitle("Accurancy & Cost")
ax[0].plot(acc_list)
ax[1].plot(cost_list)
plt.show()